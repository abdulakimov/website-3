const CART = "cart";
const FAVORITE = "favorite";
// const SPECIALCART = "specilacart";