const CATEGORY = "category";
const FAVORITE = "favorite";


// Retrieve the cards container and favorites container

